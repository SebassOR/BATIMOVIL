freertos/freertos-kernel/event_groups.o \
 freertos/freertos-kernel/event_groups.d: \
 ../freertos/freertos-kernel/event_groups.c \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\source\mcux_config.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\freertos\freertos-kernel\include/FreeRTOS.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\freertos\freertos-kernel\template/FreeRTOSConfig.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\source/FreeRTOSConfig_Gen.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\freertos\freertos-kernel\include/projdefs.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\freertos\freertos-kernel\include/portable.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\freertos\freertos-kernel\include/deprecated_definitions.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\freertos\freertos-kernel\portable\GCC\ARM_CM33_NTZ\non_secure/portmacro.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\freertos\freertos-kernel\portable\GCC\ARM_CM33_NTZ\non_secure/portmacrocommon.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\freertos\freertos-kernel\include/mpu_wrappers.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\freertos\freertos-kernel\include/task.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\freertos\freertos-kernel\include/list.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\freertos\freertos-kernel\include/timers.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\freertos\freertos-kernel\include/task.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\freertos\freertos-kernel\include/event_groups.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\freertos\freertos-kernel\include/timers.h
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\source\mcux_config.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\freertos\freertos-kernel\include/FreeRTOS.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\freertos\freertos-kernel\template/FreeRTOSConfig.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\source/FreeRTOSConfig_Gen.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\freertos\freertos-kernel\include/projdefs.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\freertos\freertos-kernel\include/portable.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\freertos\freertos-kernel\include/deprecated_definitions.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\freertos\freertos-kernel\portable\GCC\ARM_CM33_NTZ\non_secure/portmacro.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\freertos\freertos-kernel\portable\GCC\ARM_CM33_NTZ\non_secure/portmacrocommon.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\freertos\freertos-kernel\include/mpu_wrappers.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\freertos\freertos-kernel\include/task.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\freertos\freertos-kernel\include/list.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\freertos\freertos-kernel\include/timers.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\freertos\freertos-kernel\include/task.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\freertos\freertos-kernel\include/event_groups.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\freertos\freertos-kernel\include/timers.h:
