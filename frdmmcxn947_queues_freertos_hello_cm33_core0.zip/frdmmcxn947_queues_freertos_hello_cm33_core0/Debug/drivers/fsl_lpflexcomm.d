drivers/fsl_lpflexcomm.o drivers/fsl_lpflexcomm.d: \
 ../drivers/fsl_lpflexcomm.c \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\source\mcux_config.h \
 ../drivers/fsl_common.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device/fsl_device_registers.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device/MCXN947_cm33_core0.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_ADC.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device/MCXN947_cm33_core0_COMMON.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\CMSIS/core_cm33.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\CMSIS/cmsis_version.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\CMSIS/cmsis_compiler.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\CMSIS/cmsis_gcc.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\CMSIS/m-profile/armv8m_mpu.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device/system_MCXN947_cm33_core0.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device/MCXN947_cm33_core0_features.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_AHBSC.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_BSP32.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_CACHE64_CTRL.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_CACHE64_POLSEL.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_CAN.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_CDOG.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_CMC.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_CRC.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_CTIMER.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_DIGTMP.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_DM.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_DMA.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_EIM.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_EMVSIM.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_ENET.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_ERM.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_EVTG.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_EWM.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_FLEXIO.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_FLEXSPI.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_FMU.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_FMUTEST.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_FREQME.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_GDET.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_GPIO.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_HPDAC.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_I2S.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_I3C.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_INPUTMUX.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_INTM.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_ITRC.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_LPCMP.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_LPDAC.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_LPI2C.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_LPSPI.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_LPTMR.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_LPUART.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_LP_FLEXCOMM.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_MAILBOX.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_MRT.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_NPX.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_OPAMP.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_OSTIMER.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_OTPC.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_PDM.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_PINT.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_PKC.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_PLU.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_PORT.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_POWERQUAD.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_PUF.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_PWM.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_QDC.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_RTC.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_S50.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_SCG.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_SCT.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_SEMA42.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_SINC.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_SMARTDMA.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_SPC.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_SYSCON.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_SYSPM.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_TRDC.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_TSI.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_USB.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_USBDCD.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_USBHS.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_USBHSDCD.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_USBNC.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_USBPHY.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_USDHC.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_UTICK.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_VBAT.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_VREF.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_WUU.h \
 C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_WWDT.h \
 ../drivers/fsl_common_arm.h ../drivers/fsl_clock.h \
 ../drivers/fsl_reset.h ../drivers/fsl_lpflexcomm.h
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\source\mcux_config.h:
../drivers/fsl_common.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device/fsl_device_registers.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device/MCXN947_cm33_core0.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_ADC.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device/MCXN947_cm33_core0_COMMON.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\CMSIS/core_cm33.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\CMSIS/cmsis_version.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\CMSIS/cmsis_compiler.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\CMSIS/cmsis_gcc.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\CMSIS/m-profile/armv8m_mpu.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device/system_MCXN947_cm33_core0.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device/MCXN947_cm33_core0_features.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_AHBSC.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_BSP32.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_CACHE64_CTRL.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_CACHE64_POLSEL.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_CAN.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_CDOG.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_CMC.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_CRC.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_CTIMER.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_DIGTMP.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_DM.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_DMA.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_EIM.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_EMVSIM.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_ENET.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_ERM.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_EVTG.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_EWM.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_FLEXIO.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_FLEXSPI.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_FMU.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_FMUTEST.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_FREQME.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_GDET.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_GPIO.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_HPDAC.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_I2S.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_I3C.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_INPUTMUX.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_INTM.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_ITRC.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_LPCMP.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_LPDAC.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_LPI2C.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_LPSPI.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_LPTMR.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_LPUART.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_LP_FLEXCOMM.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_MAILBOX.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_MRT.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_NPX.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_OPAMP.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_OSTIMER.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_OTPC.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_PDM.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_PINT.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_PKC.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_PLU.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_PORT.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_POWERQUAD.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_PUF.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_PWM.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_QDC.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_RTC.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_S50.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_SCG.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_SCT.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_SEMA42.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_SINC.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_SMARTDMA.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_SPC.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_SYSCON.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_SYSPM.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_TRDC.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_TSI.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_USB.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_USBDCD.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_USBHS.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_USBHSDCD.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_USBNC.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_USBPHY.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_USDHC.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_UTICK.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_VBAT.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_VREF.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_WUU.h:
C:\Users\Sebas\Documents\MCUXpressoIDE_24.12.148\workspace\frdmmcxn947_queues_freertos_hello_cm33_core0\device\periph/PERI_WWDT.h:
../drivers/fsl_common_arm.h:
../drivers/fsl_clock.h:
../drivers/fsl_reset.h:
../drivers/fsl_lpflexcomm.h:
